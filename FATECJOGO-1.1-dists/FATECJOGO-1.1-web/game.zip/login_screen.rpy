screen login_screen():
    tag menu
    modal True
    
    # Se tiver uma imagem de fundo, descomente a linha abaixo:
    # add "images/background_login.png"
    
    frame:
        style_prefix "login"
        xalign 0.5
        yalign 0.5
        xsize 400
        ysize 500
        
        vbox:
            spacing 20
            
            # Abas Login/Cadastro
            hbox:
                xalign 0.5
                spacing 50
                
                textbutton "Login":
                    action SetScreenVariable("current_tab", "login")
                    style "login_tab_button"
                    text_style "login_tab_text"
                    
                textbutton "Cadastrar":
                    action SetScreenVariable("current_tab", "cadastro")
                    style "login_tab_button"
                    text_style "login_tab_text"
            
            # Formulário de Login
            if current_tab == "login":
                vbox:
                    spacing 15
                    
                    label "E-mail:"
                    input:
                        value ScreenVariableInputValue("login_email")
                        style "login_input"
                        
                    label "Senha:"
                    input:
                        value ScreenVariableInputValue("login_senha")
                        style "login_input"
                        password True
                    
                    textbutton "Entrar":
                        action Function(login_user, login_email, login_senha)
                        style "login_submit_button"
                        xalign 0.5
                    
                    if login_message:
                        text login_message:
                            style "login_message_text"
                            xalign 0.5
            
            # Formulário de Cadastro
            else:
                vbox:
                    spacing 15
                    
                    label "Nome:"
                    input:
                        value ScreenVariableInputValue("cadastro_nome")
                        style "login_input"
                        
                    label "E-mail:"
                    input:
                        value ScreenVariableInputValue("cadastro_email")
                        style "login_input"
                        
                    label "Senha:"
                    input:
                        value ScreenVariableInputValue("cadastro_senha")
                        style "login_input"
                        password True
                    
                    textbutton "Cadastrar":
                        action Function(cadastrar_user, cadastro_nome, cadastro_email, cadastro_senha)
                        style "login_submit_button"
                        xalign 0.5
                    
                    if cadastro_message:
                        text cadastro_message:
                            style "login_message_text"
                            xalign 0.5
            
            # Botão para voltar
            textbutton "Voltar":
                action [Hide("login_screen"), ShowMenu("main_menu")]
                style "login_back_button"
                xalign 0.5

# Estilos para a tela de login
style login_frame:
    background "#ffffff"
    padding (30, 30)

style login_tab_button:
    background None

style login_tab_text:
    size 24
    color "#333"
    hover_color "#0066cc"
    selected_color "#0066cc"

style login_input:
    xsize 340
    ysize 40
    background "#f5f5f5"

style login_submit_button:
    background "#0066cc"
    hover_background "#0052a3"
    xsize 200
    ysize 45

style login_back_button:
    background None
    color "#666"
    hover_color "#0066cc"

style login_message_text:
    size 14
    color "#cc0000"