init python:
    import urllib.request
    import json
    
    # CONFIGURAÇÃO DO FIREBASE - COLE SUA CHAVE AQUI!
    FIREBASE_API_KEY = "AIzaSyCPyNooBoyDCM9Bdex-9ReA5MMzm1duPqk"
    FIREBASE_AUTH_URL = f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={FIREBASE_API_KEY}"
    FIREBASE_SIGNUP_URL = f"https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={FIREBASE_API_KEY}"
    
    def firebase_request(url, data):
        """
        Faz requisição para o Firebase usando urllib (funciona na web)
        """
        try:
            # Converte dados para JSON
            json_data = json.dumps(data).encode('utf-8')
            
            # Configura headers
            headers = {
                'Content-Type': 'application/json',
            }
            
            # Cria requisição
            req = urllib.request.Request(url, data=json_data, headers=headers, method='POST')
            
            # Faz a requisição
            response = urllib.request.urlopen(req, timeout=10)
            response_data = response.read().decode('utf-8')
            
            return {
                'status_code': response.getcode(),
                'data': json.loads(response_data)
            }
            
        except urllib.error.HTTPError as e:
            # Captura erro HTTP
            error_data = e.read().decode('utf-8')
            return {
                'status_code': e.code,
                'data': json.loads(error_data) if error_data else {'error': {'message': 'Erro HTTP'}}
            }
        except Exception as e:
            # Captura outros erros
            return {
                'status_code': 0,
                'data': {'error': {'message': f'Erro de conexão: {str(e)}'}}
            }
    
    def login_user(email, senha):
        if not email or not senha:
            store.login_message = "Por favor, preencha todos os campos."
            return
        
        data = {
            "email": email,
            "password": senha,
            "returnSecureToken": True
        }
        
        result = firebase_request(FIREBASE_AUTH_URL, data)
        
        if result['status_code'] == 200:
            store.current_user = {
                "email": result['data']["email"],
                "id": result['data']["localId"],
                "token": result['data']["idToken"]
            }
            store.user_token = result['data']["idToken"]
            
            # Salva nos persistent data
            persistent.current_user = store.current_user
            persistent.user_token = store.user_token
            
            store.login_message = "✅ Login realizado com sucesso!"
            renpy.hide_screen("login_screen")
        else:
            error_message = result['data'].get("error", {}).get("message", "Erro desconhecido")
            store.login_message = f"❌ Erro no login: {error_message}"
    
    def cadastrar_user(nome, email, senha):
        if not nome or not email or not senha:
            store.cadastro_message = "Por favor, preencha todos os campos."
            return
        
        if len(senha) < 6:
            store.cadastro_message = "A senha deve ter pelo menos 6 caracteres."
            return
        
        data = {
            "email": email,
            "password": senha,
            "returnSecureToken": True
        }
        
        result = firebase_request(FIREBASE_SIGNUP_URL, data)
        
        if result['status_code'] == 200:
            store.current_user = {
                "nome": nome,
                "email": result['data']["email"],
                "id": result['data']["localId"],
                "token": result['data']["idToken"]
            }
            store.user_token = result['data']["idToken"]
            
            # Salva nos persistent data
            persistent.current_user = store.current_user
            persistent.user_token = store.user_token
            
            store.cadastro_message = "✅ Cadastro realizado com sucesso!"
        else:
            error_message = result['data'].get("error", {}).get("message", "Erro desconhecido")
            store.cadastro_message = f"❌ Erro no cadastro: {error_message}"
    
    def logout_user():
        store.current_user = None
        store.user_token = None
        persistent.current_user = None
        persistent.user_token = None

# Variáveis padrão
default current_tab = "login"
default login_email = ""
default login_senha = ""
default login_message = ""
default cadastro_nome = ""
default cadastro_email = ""
default cadastro_senha = ""
default cadastro_message = ""
default current_user = None
default user_token = None

# Inicializar persistent data
init 1 python:
    if not hasattr(persistent, 'current_user'):
        persistent.current_user = None
    if not hasattr(persistent, 'user_token'):
        persistent.user_token = None