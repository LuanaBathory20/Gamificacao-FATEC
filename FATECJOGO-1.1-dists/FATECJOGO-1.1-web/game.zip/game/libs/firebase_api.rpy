init python:
    import requests
    import json
    
    # CONFIGURAÇÃO DO FIREBASE - IMPORTANTE: ALTERE ESTES DADOS!
    FIREBASE_API_KEY = "224613835263"
    FIREBASE_AUTH_URL = f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={FIREBASE_API_KEY}"
    FIREBASE_SIGNUP_URL = f"https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={FIREBASE_API_KEY}"
    
    def login_user(email, senha):
        if not email or not senha:
            store.login_message = "Por favor, preencha todos os campos."
            return
        
        data = {
            "email": email,
            "password": senha,
            "returnSecureToken": True
        }
        
        try:
            response = requests.post(FIREBASE_AUTH_URL, json=data)
            result = response.json()
            
            if response.status_code == 200:
                store.current_user = {
                    "email": result["email"],
                    "id": result["localId"],
                    "token": result["idToken"]
                }
                store.user_token = result["idToken"]
                store.login_message = "Login realizado com sucesso!"
                renpy.save_persistent()
                renpy.hide_screen("login_screen")
            else:
                error_message = result.get("error", {}).get("message", "Erro desconhecido")
                store.login_message = f"Erro no login: {error_message}"
                
        except Exception as e:
            store.login_message = f"Erro de conexão: {str(e)}"
    
    def cadastrar_user(nome, email, senha):
        if not nome or not email or not senha:
            store.cadastro_message = "Por favor, preencha todos os campos."
            return
        
        if len(senha) < 6:
            store.cadastro_message = "A senha deve ter pelo menos 6 caracteres."
            return
        
        data = {
            "email": email,
            "password": senha,
            "returnSecureToken": True
        }
        
        try:
            response = requests.post(FIREBASE_SIGNUP_URL, json=data)
            result = response.json()
            
            if response.status_code == 200:
                store.current_user = {
                    "nome": nome,
                    "email": result["email"],
                    "id": result["localId"],
                    "token": result["idToken"]
                }
                store.user_token = result["idToken"]
                store.cadastro_message = "Cadastro realizado com sucesso!"
                renpy.save_persistent()
            else:
                error_message = result.get("error", {}).get("message", "Erro desconhecido")
                store.cadastro_message = f"Erro no cadastro: {error_message}"
                
        except Exception as e:
            store.cadastro_message = f"Erro de conexão: {str(e)}"
    
    def logout_user():
        store.current_user = None
        store.user_token = None
        renpy.save_persistent()

# Variáveis padrão
default current_tab = "login"
default login_email = ""
default login_senha = ""
default login_message = ""
default cadastro_nome = ""
default cadastro_email = ""
default cadastro_senha = ""
default cadastro_message = ""
default current_user = None
default user_token = None