﻿# Adicione estas linhas no início do script.rpy
init python:
    # Isso garante que as funções do Firebase sejam carregadas primeiro
    pass

define l = Character("Luana")
define n = Character("Novato")
define p = Character("Paula Professora")

image Lume normal = "images/LU1.png"
image Lume fallab = "images/LU2.png"
image fundo = "images/background.png"
image Paula professora = "images/PA1.png"
image Luana normal = "images/LU1.png"
image Luana falado = "images/LU2.png"
image Paula professora normal = "images/PA2.png"
image Paula professora falado = "images/PA1.png"

label start:
    # Inicialização das variáveis persistentes (forma correta)
    python:
        if not hasattr(persistent, 'current_user'):
            persistent.current_user = None
        if not hasattr(persistent, 'user_token'):
            persistent.user_token = None
        
        # Copia dados persistentes para variáveis globais
        store.current_user = persistent.current_user
        store.user_token = persistent.user_token
    
    scene black
    
    "Bem-vindo ao jogo!"
    
    show fundo:
        zoom 1.2
    with fade

    show Luana falado at left:
        zoom 1.4
        yalign 1.3
    with dissolve

    l "Oi! Você deve ser calouro por aqui, né? Bem-vindo à FATEC Matão! Eu sou a Luana, do terceiro semestre. Posso te mostrar tudo o que precisa saber."

    show Luana normal at left:
        zoom 1.4
        yalign 1.3
    with dissolve

    n "Ah, obrigado… é tudo tão novo. Eu tô meio perdido."

    show Luana falado at left:
        zoom 1.4
        yalign 1.3
    with dissolve

    l "Relaxa! A gente também ficou assim no começo. Vem comigo, vou te explicar como funcionam as salas, os laboratórios e o Wi-Fi — sim, a gente sempre se atrapalha com a senha."

    show Luana normal at left:
        zoom 1.4
        yalign 1.3
    with dissolve

menu:
    "Acessando o e-mail institucional":
        show Luana falado at left:
            zoom 1.4
            yalign 1.3
        with dissolve
        l "Ah, uma coisa importante: seu e-mail da FATEC! É por lá que você vai receber avisos dos professores, da coordenação e até da biblioteca."
        show Luana normal at left:
            zoom 1.4
            yalign 1.3
        with dissolve
        n "Sério? Como eu faço pra acessar?"
        show Luana falado at left:
            zoom 1.4
            yalign 1.3
        with dissolve
        l "Na primeira semana de aula, você vai receber um e-mail no seu e-mail pessoal — aquele que você usou na matrícula. Esse e-mail vem da Diretoria Acadêmica e traz seu novo e-mail da FATEC, que termina com @fatec.sp.gov.br, e uma senha inicial."
        l "Aí é só entrar no site da Microsoft pelo link que vem nesse email, digitar seu novo e-mail e senha. Assim que você fizer o primeiro login, o sistema vai pedir pra você trocar a senha por uma só sua."
        l "Ah, e se quiser, pode ativar a autenticação em duas etapas — é tipo um código de segurança extra."
        show Luana normal at left:
            zoom 1.4
            yalign 1.3
        with dissolve
        n "Esse login serve só para o e-mail?"
        show Luana falado at left:
            zoom 1.4
            yalign 1.3
        with dissolve
        l "Não só! Ele também serve pra entrar no Microsoft Teams, salvar coisas no OneDrive e usar os apps do Office, tipo Word e PowerPoint Online. Tudo gratuito, porque somos alunos da FATEC Matão!"
        show Luana normal at left:
            zoom 1.4
            yalign 1.3
        show Paula professora falado at right:
            zoom 1.7
            yalign 3.1
        with dissolve
        p "Olá! Que bom ter você conosco. Eu sou a profa. Paula, da disciplina de Design Digital. Na FATEC Matão, usamos o e-mail institucional para tudo: comunicação com os professores, equipes de projeto e avisos importantes."
        p "Se você tiver qualquer dificuldade com tecnologia ou acesso, pode procurar a gente. Estamos aqui pra te apoiar, no seu tempo, do seu jeito."
        jump continuar_historia

    "Conhecendo o Laboratório de Informática":
        show Luana falado at left:
            zoom 1.4
            yalign 1.3
        with dissolve
        l "Os computadores são usados nas aulas práticas, e cada laboratório tem um número: Lab 1, Lab 2, Lab 3… e por aí vai."
        show Luana normal at left:
            zoom 1.4
            yalign 1.3
        with dissolve
        n "Como eu faço pra logar nos computadores?"
        show Luana falado at left:
            zoom 1.4
            yalign 1.3
        with dissolve
        l "Boa pergunta! Na primeira semana, a Diretoria Acadêmica vai liberar pra você um login e senha. Guarde bem para conseguir acessar os computadores sempre que precisar."
        l "Ah! E muito importante: sempre salve seus arquivos no OneDrive, para poder acessar seus arquivos de qualquer laboratório, ou mesmo na sua casa."
        show Luana normal at left:
            zoom 1.4
            yalign 1.3
        show Paula professora falado at right:
            zoom 1.7
            yalign 3.1
        with dissolve
        p "Oi! Seja muito bem-vindo. Eu sou a profa. Paula. Aqui na FATEC Matão, os laboratórios são como oficinas de criação. É onde você vai experimentar, errar, acertar… e aprender fazendo."
        p "Se precisar de suporte técnico, ajuda com equipamentos ou quiser adaptar seu jeito de trabalhar, pode contar com toda a equipe da FATEC Matão. Cada estudante tem um jeito único de aprender — e a gente valoriza isso."
        jump continuar_historia

    "Descobrindo o que é um Projeto Interdisciplinar":
        show Luana falado at left:
            zoom 1.4
            yalign 1.3
        with dissolve
        l "AAhhh, o famoso PI! É tipo uma missão especial que a gente faz a cada semestre."
        l "Funciona assim: a gente junta os conteúdos das matérias e faz um projeto prático que resolve um problema real. Cada semestre tem um foco diferente, mas evoluímos em cima do mesmo tema com que começamos no primeiro semestre."
        show Luana normal at left:
            zoom 1.4
            yalign 1.3
        show Paula professora falado at right:
            zoom 1.7
            yalign 3.1
        with dissolve
        p "Olá! Que bom ter você conosco. Eu sou a profa. Paula, da disciplina de Design Digital. A FATEC Matão é uma faculdade pública, gratuita e de qualidade. Aqui, a gente aprende na prática, nestes projetos integrados com outras disciplinas."
        p "Os Projetos Interdisciplinares ajudam você a aprender fazendo. Você aplica o que aprende em sala numa situação real — como criar um sistema, um site, um app, um jogo… geralmente em grupo, com orientação dos professores."
        p "É onde você começa a sentir como é trabalhar em equipe, lidar com prazos e construir algo que pode ser usado de verdade."
        show Paula professora normal at right:
            zoom 1.7
            yalign 3.1
        with dissolve
        n "Uau! Parece desafiador… mas bem legal. Nem sei ainda por onde começar…"
        show Luana falado at left:
            zoom 1.4
            yalign 1.3
        with dissolve
        l "Fica tranquilo: ninguém nasce sabendo. A gente aprende junto, e os professores sempre ajudam."
        show Luana normal at left:
            zoom 1.4
            yalign 1.3
        show Paula professora falado at right:
            zoom 1.7
            yalign 3.1
        with dissolve
        p "Você pode contar com a ajuda de professores, monitores e colegas. E se precisar de acessibilidade, tecnologia assistiva ou apoio, é só procurar a coordenação. Você é bem-vindo aqui do seu jeito!"
        jump continuar_historia

label continuar_historia:
    # Continuação da história após a escolha do menu 
    show Luana falado at left:
        zoom 1.4
        yalign 1.3
    with dissolve
    
    l "Bom, agora que você já conhece um pouco mais da FATEC, que tal explorar outros lugares?"
    
    show Luana normal at left:
        zoom 1.4
        yalign 1.3
    with dissolve
    
    n "Com certeza! Obrigado pela ajuda, Luana!"
    
    "E assim começou sua jornada na FATEC Matão..."
    
    return