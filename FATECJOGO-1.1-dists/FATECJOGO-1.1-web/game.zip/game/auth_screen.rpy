screen auth_screen():
    tag menu
    modal True
    
    default current_tab = "login"
    default login_email = ""
    default login_senha = ""
    default login_message = ""
    default login_message_type = ""
    default remember_me = False
    default show_password = False
    
    default cadastro_nome = ""
    default cadastro_email = ""
    default cadastro_senha = ""
    default cadastro_message = ""
    default cadastro_message_type = ""
    default show_cadastro_password = False
    
    frame:
        style "modern_login_frame"
        xalign 0.5
        yalign 0.5
        
        vbox:
            style "login_main_vbox"
            
            # Seletor de Abas
            hbox:
                style "tab_selector_hbox"
                
                textbutton "Entrar":
                    style "tab_button_{}".format("active" if current_tab == "login" else "inactive")
                    action SetScreenVariable("current_tab", "login")
                
                textbutton "Cadastrar":
                    style "tab_button_{}".format("active" if current_tab == "cadastro" else "inactive")
                    action SetScreenVariable("current_tab", "cadastro")
            
            if current_tab == "login":
                # === FORMULÁRIO DE LOGIN ===
                vbox:
                    style "login_form_vbox"
                    
                    # Cabeçalho Login
                    vbox:
                        style "login_header"
                        text "Entrar":
                            style "login_title"
                        text "Use seu e-mail e senha para acessar o sistema.":
                            style "login_subtitle"
                    
                    # Campo E-mail
                    vbox:
                        style "form_group"
                        text "E-mail":
                            style "input_label"
                        input:
                            value VariableInputValue("login_email")
                            style "modern_input"
                    
                    # Campo Senha
                    vbox:
                        style "form_group"
                        text "Senha":
                            style "input_label"
                    # No campo senha do login:
                        hbox:
                            style "password_hbox"
                            if show_password:
                                input:
                                    value VariableInputValue("login_senha")
                                    style "password_input"
                            else:
                                input:
                                    value VariableInputValue("login_senha")
                                    style "password_input"
                                    mask "*"    
                            
                    
                    # Botão Entrar
                    textbutton "Entrar":
                        style "modern_submit_button"
                        action Function(login_user, login_email, login_senha, remember_me)
                    
                    # Mensagem
                    if login_message:
                        text login_message:
                            style "login_message_text_{}".format(login_message_type)
                            
            
            else:
                # === FORMULÁRIO DE CADASTRO ===
                vbox:
                    style "login_form_vbox"
                    
                    # Cabeçalho Cadastro
                    vbox:
                        style "login_header"
                        text "Criar Conta":
                            style "login_title"
                        text "Preencha os dados para criar sua conta.":
                            style "login_subtitle"
                    
                    # Campo Nome
                    vbox:
                        style "form_group"
                        text "Nome Completo":
                            style "input_label"
                        input:
                            value VariableInputValue("cadastro_nome")
                            style "modern_input"
                            
                    
                    # Campo E-mail
                    vbox:
                        style "form_group"
                        text "E-mail":
                            style "input_label"
                        input:
                            id "email_input"
                            value VariableInputValue("cadastro_email")
                            style "modern_input"
                           
                    
                    # Campo Senha
                    vbox:
                        style "form_group"
                        text "Senha":
                            style "input_label"
                        # No campo senha do Cadastro:
                        hbox:
                            style "password_hbox"
                            if show_password:
                                input:
                                    value VariableInputValue("cadastro_senha")
                                    style "password_input"
                            else:
                                input:
                                    value VariableInputValue("cadastro_senha")
                                    style "password_input"
                                    mask "*"
                    

                    # Botão Cadastrar
                    textbutton "Cadastrar":
                        style "modern_submit_button"
                        action Function(register_user, cadastro_nome, cadastro_email, cadastro_senha)
                        
                    
                    # Mensagem Cadastro
                    if cadastro_message:
                        text cadastro_message:
                            style "login_message_text_{}".format(cadastro_message_type)
                            
            
            textbutton "Já tem conta? Fazer login":
                style "signup_link_button"
                action SetScreenVariable("current_tab", "login")
                xalign 0.5
                

            # Botão Voltar
            textbutton "Voltar":
                style "modern_back_button"
                action [Hide("auth_screen"), ShowMenu("main_menu")]